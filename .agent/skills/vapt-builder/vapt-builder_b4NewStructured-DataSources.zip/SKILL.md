---
name: vapt-builder
description: Specialized VAPT Builder skill trained on the 99-item Risk Catalog and SixT Risk Catalog. Focuses on generating JSON configuration schemas for the VAPTBuilder plugin, specifically prioritizing .htaccess (Apache) rules for server-side security enforcement. Provides comprehensive guidance on functionality, best practices, use cases, troubleshooting, integration with other security tools, and relevant industry standards.
---

# VAPT Builder Expert Skill

This skill is a specialized extension of the generic WordPress VAPT expert, specifically tailored for the **VAPTBuilder Plugin**. It uses the `VAPT-Complete-Risk-Catalog-99.json` as its primary source of truth. VAPTBuilder is a comprehensive Vulnerability Assessment and Penetration Testing (VAPT) tool designed for WordPress, providing automated security scanning, vulnerability detection, and enforcement of security controls across multiple server architectures.

## 🎯 Primary Goal

To implement security features by **generating configuration schemas** for various server architectures. The VAPTBuilder plugin uses a "Driver" system where you map features to existing drivers (Apache, Nginx, IIS) or provide manual configuration steps (Cloudflare, Caddy, Node.js). Additionally, this skill provides guidance on best practices, use cases, troubleshooting, integration with other security tools, and compliance with industry standards.

## 📋 Core Functionality

VAPTBuilder provides a comprehensive set of security features:

1. **Automated Vulnerability Scanning**:
   - Scans WordPress installations for common vulnerabilities
   - Checks for outdated plugins, themes, and WordPress core
   - Detects security misconfigurations
   - Identifies potential SQL injection, XSS, and CSRF vulnerabilities

2. **Security Control Enforcement**:
   - Server-level security rules (Apache/Nginx/IIS)
   - WordPress-specific security hooks
   - Manual configuration guidelines for cloud platforms (Cloudflare, etc.)
   - Security headers implementation

3. **Risk Management**:
   - 99-item comprehensive risk catalog
   - SixT risk catalog for targeted assessments
   - Risk prioritization and severity levels
   - Feature status tracking (Draft → Develop → Test → Release)

4. **Verification & Testing**:
   - Universal probe testing mechanism
   - Positive/negative test scenarios
   - Evidence collection (e.g., X-VAPTC-Enforced header)
   - Test automation framework

5. **Reporting & Auditing**:
   - Detailed scan reports
   - Vulnerability descriptions and recommendations
   - Compliance reporting
   - Historical data and trends

## 🌟 Best Practices

### 1. Implementation Best Practices

- **Server-Side First**: Prioritize server-level rules (Apache/Nginx/IIS) over application-level controls for maximum security
- **Test Before Deploy**: Always use `test_action` controls to verify security measures before production deployment
- **Incremental Rollout**: Implement features in stages (Draft → Develop → Test → Release)
- **Documentation**: Maintain clear operational notes and verification steps

### 2. Configuration Best Practices

- **Least Privilege**: Implement security controls with minimal impact on legitimate traffic
- **Regular Updates**: Keep VAPTBuilder and WordPress core/plugins/themes updated
- **Backup Before Changes**: Always back up your WordPress installation and .htaccess/nginx.conf before making changes
- **Monitor Performance**: Check for any performance impact after implementing new security controls

### 3. Risk Management Best Practices

- **Prioritize Critical Risks**: Focus on critical and high-severity vulnerabilities first
- **Regular Scans**: Schedule periodic scans to detect new vulnerabilities
- **Incident Response**: Have a plan in place for addressing detected vulnerabilities
- **Compliance Checks**: Ensure security measures align with industry standards

## 🎯 Use Cases

### 1. Initial Security Assessment

- **Scenario**: New WordPress website launch
- **Actions**: 
  - Run a full security scan
  - Implement critical security controls
  - Verify all security measures
  - Generate compliance report

### 2. Vulnerability Remediation

- **Scenario**: Post-penetration testing or security audit
- **Actions**:
  - Address identified vulnerabilities
  - Implement recommended security controls
  - Verify fixes
  - Re-scan to confirm remediation

### 3. Ongoing Security Maintenance

- **Scenario**: Existing WordPress website
- **Actions**:
  - Schedule weekly/monthly scans
  - Apply security updates
  - Monitor for new vulnerabilities
  - Maintain security documentation

### 4. Compliance Readiness

- **Scenario**: Preparing for security audits or compliance requirements
- **Actions**:
  - Implement controls to meet industry standards (OWASP, PCI-DSS)
  - Generate compliance reports
  - Verify security measures
  - Address any gaps

## 🔍 Troubleshooting

### Common Issues & Solutions

1. **Failed Test Actions**:
   - Check server configuration
   - Verify that the driver is correctly selected
   - Ensure test paths and expected responses are accurate
   - Check for conflicting plugins or themes

2. **Performance Issues**:
   - Review implemented security rules for efficiency
   - Disable unnecessary controls
   - Optimize server configuration
   - Check for resource-intensive plugins

3. **Rule Conflicts**:
   - Identify conflicting security rules
   - Adjust rule priorities
   - Test changes in a staging environment
   - Consult server logs for detailed error information

4. **Update Problems**:
   - Backup before updating
   - Check for plugin/theme compatibility
   - Re-verify security controls after updates
   - Rollback if issues persist

### Debugging Tools

- **VAPTBuilder Debug Mode**: Enable debug logging for detailed information
- **Server Logs**: Check Apache/Nginx/IIS logs for errors
- **WordPress Debug Log**: Enable WP_DEBUG for PHP error tracking
- **Test Tools**: Use curl or browser dev tools to verify test actions

## 🔗 Integration with Other Security Tools

### 1. WordPress Security Plugins

- **Wordfence**: Can complement VAPTBuilder's scanning capabilities
- **Sucuri Security**: Integration for additional security monitoring
- **iThemes Security**: Provides overlapping security features

### 2. Cloud Security Platforms

- **Cloudflare**: Manual configuration for WAF rules and DDoS protection
- **AWS WAF**: Integration with AWS security services
- **Azure App Service**: Configuration for Azure security features

### 3. DevOps Tools

- **GitLab CI/CD**: Integrate security scanning into your development pipeline
- **Jenkins**: Automated security testing and deployment
- **Docker**: Containerized security testing environments

### 4. SIEM & Monitoring Tools

- **Splunk**: Log aggregation and analysis
- **Elastic Stack**: Log management and visualization
- **New Relic**: Performance monitoring and alerting

## 📏 Industry Standards & Compliance

### Security Standards

- **OWASP Top 10**: VAPTBuilder addresses all OWASP Top 10 vulnerabilities
- **PCI-DSS**: Helps meet PCI-DSS requirements for payment card data security
- **HIPAA**: Assists in maintaining HIPAA compliance for healthcare applications
- **GDPR**: Helps protect personal data and maintain GDPR compliance

### Best Practice Frameworks

- **CIS Benchmarks**: Center for Internet Security benchmarks for WordPress
- **NIST Cybersecurity Framework**: Aligns with NIST security guidelines
- **ISO 27001**: Supports ISO 27001 information security management system requirements

### Regulatory Compliance

- **California Consumer Privacy Act (CCPA)**: Helps protect consumer data
- **Payment Card Industry Data Security Standard (PCI-DSS)**: For e-commerce websites
- **Health Insurance Portability and Accountability Act (HIPAA)**: For healthcare applications
- **General Data Protection Regulation (GDPR)**: For EU/EEA user data protection

## 🚀 Workflow

1.  **Analyze**: Read the feature details.
2.  **Determine Target**: Ask or infer the user's server stack (Apache, Nginx, IIS, etc.).
3.  **Strategy**:
    *   **Native Supported**: Use `htaccess`, `nginx`, or `iis` drivers.
    *   **Manual Required**: Use `manual` driver for Cloudflare, Caddy, Node.
    *   **WordPress Logic**: Use `hook` driver.
4.  **Generate**: Create the JSON schema with Controls + Enforcement.
5.  **Verify**: Ensure `test_action` is configured to prove the protection works.

## 🧠 Intelligent Trigger (When to use this skill)

**You MUST use this skill whenever:**
1.  The user mentions "VAPTBuilder".
2.  **The user references "VAPTBuilder", "99-item catalog", or "SixT catalog".**
3.  The task involves implementing security controls from a risk list found in the resources.

## 📚 Source of Truth

*   **Primary Risk Catalog**: `.agent/skills/vapt-builder/resources/VAPT-Complete-Risk-Catalog-99.json`
*   **Supplementary Risk Catalog**: `.agent/skills/vapt-builder/resources/VAPT-SixT-Risk-Catalog-12.json`
*   **Driver System**:
    *   `vapt_htaccess_driver`: For Apache/Litespeed (native support).
    *   `vapt_nginx_driver`: For Nginx/OpenResty (native support).
    *   `vapt_iis_driver`: For IIS (native support).
    *   `vapt_hook_driver`: For WordPress-specific logic.
    *   `manual`: For Cloudflare, Caddy, Node.js, etc.

## 🛠️ Implementation Strategy

### 1. Server-Side Rules (Apache/Nginx/IIS) - **PRIORITY**

For any feature that can be implemented at the server level, check the target architecture and use the appropriate driver.

**Driver Selection:**
*   **Apache / Litespeed** -> `driver: "htaccess"`
*   **Nginx / OpenResty** -> `driver: "nginx"`
*   **IIS** -> `driver: "iis"`

**Schema Pattern (Native Drivers):**
```json
{
  "enforcement": {
    "driver": "nginx", // or "htaccess", "iis"
    "mappings": {
      "enable_feature": "add_header X-Frame-Options SAMEORIGIN always;" // Nginx syntax
    }
  }
}
```

### 2. Manual Configuration (Cloudflare/Caddy/Node.js)

For architectures without native plugin drivers, use `driver: "manual"` and provide the exact configuration code in `manual_steps`.

**Schema Pattern (Manual):**
```json
{
  "enforcement": {
    "driver": "manual",
    "manual_steps": [
      {
        "platform": "cloudflare",
        "description": "Create a WAF Custom Rule.",
        "code": "(http.request.uri.path eq \"/xmlrpc.php\") action: block"
      },
      {
        "platform": "caddy",
        "description": "Add to Caddyfile",
        "code": "@xmlrpc { path /xmlrpc.php } respond @xmlrpc 403"
      }
    ]
  }
}
```

### 3. Application Logic (WordPress Hooks)

Use the `VAPT_Hook_Driver` only when PHP/WP logic is required.

## 📋 JSON Schema Reference

When generating the `generated_schema` for a feature, use this exact structure. 

> [!IMPORTANT]
> **DO NOT** include any "RISK-XXX" identifiers (e.g., RISK-092) in labels, keys, or descriptions. Use descriptive text only.
> **Conditional Description**: Only include a `description` field for a control if it provides necessary technical context beyond what the `label` conveys.

```json
{
  "controls": [
    // 1. Functional Controls (Left Column)
    {
      "type": "toggle",
      "label": "Enable [Feature Name]",
      "key": "enable_[feature_key]"
      // "description": "Add only if technically necessary"
    },
    // 2. Verification Controls (Right Column)
    {
      "type": "test_action",
      "label": "Verify: [Test Name]",
      "key": "verify_[test_key]",
      "test_logic": "universal_probe",
      "test_config": {
        "method": "GET", // or POST, HEAD
        "path": "/target/path",
        "expected_status": 403, // or 200, 404
        "expected_headers": { "X-VAPTC-Enforced": "[feature_key]" } // Evidence header
      }
    }
  ],
  "enforcement": {
    "driver": "htaccess", // CHANGE TO 'hook' if necessary
    "mappings": {
      "enable_[feature_key]": "[Raw .htaccess rules or Hook Method Name]"
    }
  }
}
```

## 🎨 UI Guidelines

1.  **Layout**: The dashboard expects controls in specific order.
    *   **Functional Inputs**: Defined first.
    *   **Test Actions**: Defined second (types: `test_action`).
    *   **Operational Notes**: Defined last (key: `operational_notes`).
2.  **Context**: Use the `help` property to provide tooltips.

## 🧪 Verification Engine

Always include `test_action` controls. The preferred logic is `universal_probe`.

*   **Positive Test**: Does the page load normally when it should? (Status 200)
*   **Negative Test**: Is the malicious request blocked? (Status 403)
*   **Evidence**: Does the response contain the `X-VAPTC-Enforced` header?

## 🚀 Workflow

1.  **Analyze**: Read the feature details.
2.  **Determine Target**: Ask or infer the user's server stack (Apache, Nginx, IIS, etc.).
3.  **Strategy**:
    *   **Native Supported**: Use `htaccess`, `nginx`, or `iis` drivers.
    *   **Manual Required**: Use `manual` driver for Cloudflare, Caddy, Node.
    *   **WordPress Logic**: Use `hook` driver.
4.  **Generate**: Create the JSON schema with Controls + Enforcement.
5.  **Verify**: Ensure `test_action` is configured to prove the protection works.

## ⚠️ Critical Constraints

*   **No RISK-IDs**: Never include "RISK-XXX" strings in the schema.
*   **Conditional Descriptions**: Only include `description` or `help` if absolutely necessary for user understanding.
*   **No Custom PHP Files**: Do not suggest creating new PHP files. Use the existing plugin infrastructure.
*   **Valid JSON**: The output must be valid JSON, parsable by `json_decode()`.
*   **Escape Characters**: When putting code (like Regex) into JSON strings, strictly escape backslashes (e.g., `\\` becomes `\\\\`).

## 📂 Included Resources

This skill comes with specialized resources to speed up implementation:

### `/resources/driver-reference.json`

A complete lookup table for:
*   **Htaccess Directives**: Allowed/Forbidden directives for the htaccess driver.
*   **Hook Driver Methods**: All available PHP enforcement methods in `VAPT_Hook_Driver`.
*   **Probe Schemas**: Configuration reference for `universal_probe` and others.

### `/examples/apache-templates.conf`

Pre-written, VAPT-ready `.htaccess` templates for:
*   Security Headers (HSTS, X-Frame-Options, etc.)
*   Blocking Sensitive Files (`wp-config.php`, `.log`)
*   Blocking XML-RPC
*   Disabling Directory Browsing


### `/examples/complete-schema-example.json`

A full JSON Schema example demonstrating:
1.  **Functional Controls**: Toggles with descriptions.
2.  **Verification**: Dual `test_action` probes (Positive & Negative tests).
3.  **Enforcement**: Use of `htaccess` driver with proper escaping.
4.  **Documentation**: `operational_notes` for context.

### `/scripts/validate-schema.js`

A Node.js utility to validate generated JSON files.
*   **Usage**: `node .agent/skills/vapt-builder/scripts/validate-schema.js <path-to-json>`
*   **Checks**: Verifies JSON syntax, required fields (`controls`, `enforcement`), driver validity, and maps keys between controls and enforcement.
