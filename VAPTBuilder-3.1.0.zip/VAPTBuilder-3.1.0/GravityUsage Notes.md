Date        User              Notes
Tue, 2026-01-20  Cosmic186         Stil Some Credits Left
Tue, 2026-01-20  tanveeratcreasoft Just started @13:32
Wed, 2026-01-21  tanveeratcs       Didn't Work @09:56
Thu, 2026-01-22  tanmalik786       Consumed
Thu, 2026-01-22  tanveeratlogicx   Works.. have to close and Restart the Antigravity App
Fri, 2026-01-23  tanveeratlogicx   
Sat, 2026-01-24  tanveeraasdev     It didn't work - used @11:27
Sat, 2026-01-24  tanmalik999       used at @21:46
Mon, 2026-01-26  GuestUseratG      Using 

I've analyzed the logs and found a critical IP Mismatch Bug.

The Problem:

When you load the Settings page, the server sees your IP (139.x).
But when the Browser sends the Cron Test, the server sees its own IP (23.x).


I changed the data file to `T:\~\Local925 Sites\hermasnet\app\public\wp-content\plugins\VAPTBuilder\data\VAPT-Complete-Risk-Catalog-99.json`, and it had failed to load any features because this had a different Data Structure.
Can we change it in a way [BUT Progressively] that Plugin works equally good with both of these Structure's - All other files use a common Structure but `T:\~\Local925 Sites\hermasnet\app\public\wp-content\plugins\VAPTBuilder\data\VAPT-Complete-Risk-Catalog-99.json' uses a different JSON Structure.
I need you to create a plan and then roll it out in steps carefully not to break the Plugins.

# Map Include Fields via JSON Source [Modal]
Staying on the Feature's List tab, help me automate the Process of Identifying the correct Mapping and Assigning to the Form Fields - Based on the Active JSON Data file, dynamically.
1. Test Method Source
2. Verification Steps Source
3. Verification Engine Source

The Superadmin may override the suggested mappings if required.
